## Install IUS Repository on RedHat and CentOS systems

This role performs the following tasks:
  - Installs IUS repository based on OS distribution and version

This role requires the following variables to be set:
  - None
